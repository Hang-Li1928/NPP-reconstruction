The package is a demo. The area in the code is just a subset of our study areas. You can run the reconstructNPP_test.m firstly and then run the assign_coordinate_to_tif later.

The matlab code is to reconstruct the annual NPP map. Please run the code with the 2019a or higher version.

The python code is to set the coordinate systems for the series map. Make sure you have arcmap 10.4 or higher version.

Do not run subsect_areas.py.