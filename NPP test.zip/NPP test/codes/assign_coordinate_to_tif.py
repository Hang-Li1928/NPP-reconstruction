
#encoding=utf-8 
import numpy as np
import scipy
from scipy import optimize
import os
import arcpy
import glob  
from arcpy.sa import *
from arcpy import env
env.overwriteOutput = True
arcpy.CheckOutExtension("Spatial")
env.workspace = "C:\\Users\\Administrator\\Desktop\\NPP test\\result"




# Get input Raster properties
inRas = "C:\\Users\\Administrator\\Desktop\\NPP test\codes\\sample.tif"


input_raster = Raster(inRas)


lowerLeft = Point(input_raster.extent.XMin,input_raster.extent.YMin)
cellSize = input_raster.meanCellWidth
spatial_ref = arcpy.Describe(input_raster).spatialReference



n=0
aa = 0
value = []
name = "temp.tif"

rasters = arcpy.ListRasters("sim*.tif","TIF")


kk = len(rasters)



#  the code is for the simulated NPP
full_array = np.full((60,60,kk),1)



for raster1 in rasters:

	raster = raster1
	
	array = arcpy.RasterToNumPyArray(raster)
	
	
	full_array[:,:,aa] = array
		


	

for k in range(0,kk):
	Npp_project2 = arcpy.NumPyArrayToRaster(full_array[:,:,k],lowerLeft,cellSize,value_to_nodata=-1)
	
	Npp_project = Reclassify(Npp_project2, "Value", RemapValue([[-1,"NODATA"]]))
	arcpy.DefineProjection_management(Npp_project, spatial_ref)
	
	
	k1 = k + 1941
	print k1
	
	b_name = "C:\\Users\\Administrator\\Desktop\\NPP test\\result_coor\\NPP" + str(k1) + "_coordi.tif"

	Npp_project.save(b_name)
	

	
#the code is for the best match species

rasters = arcpy.ListRasters("best*.tif","TIF")
k = 0
aa = 0


kk = len(rasters)
full_array = np.full((60,60,kk),1)


for raster1 in rasters:

	raster = raster1
	
	array = arcpy.RasterToNumPyArray(raster)
	
	
	full_array[:,:,aa] = array
		
	aa = aa + 1

	

for k in range(0,kk):
	Npp_project2 = arcpy.NumPyArrayToRaster(full_array[:,:,k],lowerLeft,cellSize,value_to_nodata=-1)
	
	Npp_project = Reclassify(Npp_project2, "Value", RemapValue([[-1,"NODATA"]]))
	arcpy.DefineProjection_management(Npp_project, spatial_ref)
	
	
	k1 = k + 1
	print k1
	
	b_name = "C:\\Users\\Administrator\\Desktop\\NPP test\\result_coor\\best" + str(k1) + "_coordi.tif"

	Npp_project.save(b_name)
	

	
# we can operate this codes, when the input have decimals, the code is for the p value map

rasters = arcpy.ListRasters("p*.tif","TIF")

aa = 0
kk = len(rasters)
full_array1 = np.full((60,60,kk),1)


full_array = full_array1.astype(float) 

for raster1 in rasters:

	raster = raster1
	print raster
	
	array = arcpy.RasterToNumPyArray(raster)
	
	
	full_array[:,:,aa] = array
		
	aa = aa + 1


for k in range(0,kk):
	Npp_project2 = arcpy.NumPyArrayToRaster(full_array[:,:,k],lowerLeft,cellSize,value_to_nodata=-1)
	
	Npp_project = Reclassify(Npp_project2, "Value", RemapValue([[-1,"NODATA"]]))
	arcpy.DefineProjection_management(Npp_project, spatial_ref)
	
	
	b_name = "C:\\Users\\Administrator\\Desktop\\NPP test\\result_coor\\pvalue_coordi.tif"

	Npp_project.save(b_name)

	
# we can operate this codes, when the input have decimals, the code is for the R_square

rasters = arcpy.ListRasters("Rs*.tif","TIF")

aa = 0
kk = len(rasters)
full_array1 = np.full((60,60,kk),1)


full_array = full_array1.astype(float) 

for raster1 in rasters:

	raster = raster1
	print raster
	
	array = arcpy.RasterToNumPyArray(raster)
	
	
	full_array[:,:,aa] = array
		
	aa = aa + 1


for k in range(0,kk):
	Npp_project2 = arcpy.NumPyArrayToRaster(full_array[:,:,k],lowerLeft,cellSize,value_to_nodata=-1)
	
	Npp_project = Reclassify(Npp_project2, "Value", RemapValue([[-1,"NODATA"]]))
	arcpy.DefineProjection_management(Npp_project, spatial_ref)
	
	
	b_name = "C:\\Users\\Administrator\\Desktop\\NPP test\\result_coor\\Rsquare_coordi.tif"

	Npp_project.save(b_name)