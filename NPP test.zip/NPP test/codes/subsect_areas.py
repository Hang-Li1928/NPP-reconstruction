#  -*-coding:utf8 -*-
import os
import glob
import arcpy
import numpy as np
from arcpy.sa import *
from arcpy import env
env.overwriteOutput = True
arcpy.CheckOutExtension("Spatial")
env.workspace = "K:\\Dobbs_park\\real npp\\coordinate"

boundary = "C:/Users/Administrator/Desktop/NPP test/NPP_test_bound.shp"



rasters = arcpy.ListRasters("*.tif","TIF")
for raster in rasters:

	rr = raster.split("_")
	print rr[1]
	
	b1 = ExtractByMask(raster, boundary)
	b1_name = "C:\\Users\\Administrator\\Desktop\\NPP test\\test_data\\NPPtest_" + str(rr[1]) + ".tif"
	b1.save(b1_name)







