clc;
clear;
tic;

% input the data

%tree-ring data TWI data after detrending
tree_cores = zeros(16,74);
tree_cores(1,:) = [1.035,0.975,1.151,0.786,0.574,0.993,0.908,0.942,1.005,1.184,1.3,1.129,0.772,0.635,0.434,1.058,1.043,1.174,1.58,1.02,1.342,1.036,1.274,1.085,1.028,1.26,0.974,1.036,1.04,0.968,1.139,1.203,0.92,1.338,1.03,0.999,0.999,0.731,0.981,0.718,0.952,0.554,1.007,0.776,0.487,0.816,0.86,0.83,0.661,0.984,0.922,0.607,0.691,0.954,0.743,0.969,0.977,0.92,0.838,1.235,1.208,1.112,1.002,0.898,0.985,0.932,0.879,0.838,1.012,0.967,1.069,1.317,0.926,1.17];
tree_cores(2,:) = [0.916,0.933,1.271,0.945,0.702,1.052,0.856,0.791,0.97,0.976,1.098,1.023,0.806,0.887,0.614,1.272,1.248,0.974,1.083,1.062,1.193,1.094,1.02,0.989,1.003,1.095,0.97,0.866,1.105,0.834,0.54,0.783,0.886,1.475,1.085,1.067,1.097,0.928,1.03,0.94,0.901,0.131,0.954,0.564,0.518,0.663,0.908,0.542,0.444,0.832,1.39,0.722,1.327,1,0.821,1.077,1.099,1.02,0.983,1.304,1.284,1.147,1.084,1.007,1.405,1.016,1.146,0.867,1.139,1.092,1.06,1.156,0.51,1.152];
tree_cores(3,:) = [1.042,0.821,1.126,0.913,0.708,0.948,0.612,0.754,0.751,0.846,1.174,1.321,1.226,0.945,0.896,1.17,1.27,1.081,1.302,1.028,1.085,0.809,0.862,0.975,1.012,0.846,0.99,0.745,1.064,1.083,0.766,1.188,0.867,1.503,1.312,1.017,1.023,0.894,0.888,0.934,1.181,0.956,1.039,0.871,0.8,0.78,0.809,0.714,0.565,0.769,1.183,0.724,1.122,1.22,0.918,0.906,0.916,1.01,1.471,1.255,0.9,1.083,1.395,1,0.962,0.957,1.115,0.849,0.828,0.812,1.159,0.89,0.545,1.127];
tree_cores(4,:) = [0.654,0.62,0.906,0.791,0.56,0.753,0.832,0.957,1.175,1.379,1.444,1.573,1.217,0.686,0.524,0.961,1.026,1.375,1.238,1.262,0.988,0.906,0.922,0.943,0.716,0.844,0.728,0.501,1.077,1.137,0.739,0.987,1.088,1.35,1.343,1.299,0.89,0.858,1.18,0.937,1.482,1.059,1.309,0.411,0.33,0.773,0.932,1.237,0.322,0.467,0.946,0.794,1.236,0.816,0.621,0.635,0.842,0.683,1.796,1.798,0.824,1.522,1.337,0.941,1.193,1.206,1.241,0.927,0.997,0.86,1.519,0.884,0.1,0.123];
tree_cores(5,:) = [0.913,0.924,1.051,0.832,0.797,1.004,0.838,1.199,1.007,1.014,1.108,1.014,0.912,0.788,0.796,1.091,1.213,1.328,1.06,0.948,1.085,1.018,0.979,0.911,0.984,1.175,0.896,0.797,1.168,1.052,0.773,0.851,0.863,0.982,1.041,0.968,0.938,0.87,1.139,1.081,1.033,0.783,0.941,0.815,0.841,1.151,1.043,1.207,0.772,0.96,1.049,1.001,1.117,0.729,0.746,0.799,0.712,0.744,0.976,1.015,0.988,1.303,1.235,1.339,1.22,1.101,1.015,0.952,1.045,1.035,1.106,1.011,0.698,0.926];
tree_cores(6,:) = [0.852,0.739,0.914,0.986,0.637,1.048,0.951,1.075,1.234,1.305,1.298,1.338,0.766,0.637,0.645,0.867,0.955,1.386,1.431,0.978,0.935,0.61,0.884,1.155,0.76,1.02,0.91,0.589,1.024,0.939,0.909,0.89,0.972,1.174,1.079,0.918,0.807,0.895,0.848,0.701,0.817,0.703,1.186,0.834,0.453,0.616,0.834,1.069,0.544,0.913,1.066,0.946,1.369,1.273,1.173,0.964,1.041,1.171,1.218,1.023,0.726,1.119,1.129,1.184,1.405,1.323,1.076,0.797,0.792,1.152,1.256,0.759,0.708,0.732];
tree_cores(7,:) = [0.613,0.505,1.234,0.999,0.471,0.867,1.23,1.154,1.167,1.294,1.131,1.373,1.085,0.586,0.563,0.731,0.885,1.487,1.643,1.263,1.206,0.79,0.838,1.002,0.577,0.758,0.842,0.731,1.384,1.341,0.956,1.369,0.959,1.326,0.93,1.157,0.625,0.759,1.028,0.766,1.288,1.063,1.279,0.541,0.309,0.768,1.062,1.115,0.219,0.785,0.954,0.748,1.193,1.301,0.523,0.944,0.718,0.71,1.645,0.982,0.637,1.404,1.214,0.885,1.357,1.303,1.261,0.679,0.904,1.188,1.531,1.049,0.307,0.776];
tree_cores(8,:) = [0.894,0.965,1.414,0.768,0.653,1.303,0.69,0.859,1.093,1.076,0.953,1.235,0.931,0.552,0.771,1.11,0.868,0.914,0.948,0.889,1.303,0.783,1.173,1.176,0.872,0.9,0.574,0.568,0.802,0.681,0.421,0.983,1.047,1.252,0.964,0.859,0.9,0.934,0.908,1.164,1.199,0.852,1.384,0.92,0.626,1.088,1.285,1.273,0.619,-0.071,1.375,1.289,1.246,1.698,1.47,1.171,1.129,1.006,1.098,1.329,1.269,1.014,1.341,0.87,1.032,0.6,1.029,0.931,0.703,0.728,0.761,1.181,0.588,0.492];
tree_cores(9,:) = [0.663,0.945,0.798,0.741,0.943,1.004,0.752,1.072,1.007,1.178,1.107,0.993,0.965,0.926,1.118,1.175,0.902,1.299,1.097,1.112,0.834,1.051,1.11,0.845,1.133,0.945,0.951,0.749,0.78,0.796,0.866,0.962,1.371,1.261,1.08,1.259,0.851,0.84,0.543,0.552,0.447,0.906,0.703,0.594,0.764,0.974,0.662,0.741,0.939,1.099,0.814,1.451,1.447,0.966,0.905,1.083,0.913,1.079,1.188,1.312,1.532,1.211,1.225,0.47,0.055,0.901,1.055,1.002,0.968,1.315,1.096,1.155,0.824,1.352];
tree_cores(10,:)= [0.71,0.53,0.755,0.85,0.584,0.944,0.915,1.145,1.135,1.097,1.211,1.49,1.09,0.482,0.508,0.768,0.949,1.313,1.382,1.047,1.387,0.956,0.864,1.181,0.755,0.63,0.632,0.714,0.964,1.178,0.789,1.024,1.006,1.362,1.266,1.117,0.878,0.802,0.797,0.787,1.338,0.763,1.344,0.687,0.402,0.892,1.253,1.273,0.379,0.769,1.266,1.022,1.27,1.534,0.843,1.124,0.956,0.765,1.608,1.353,1.228,1.506,1.111,0.928,1.091,1.297,1.318,0.506,0.736,0.9,0.962,0.625,0.323,0.46];
tree_cores(11,:)= [0.811,0.676,0.973,0.905,0.696,0.957,0.997,1.011,1.167,1.324,1.477,1.469,0.99,0.797,0.651,0.91,0.876,1.186,1.154,0.947,0.779,0.942,0.946,0.708,0.655,0.826,0.692,0.823,0.96,0.976,0.803,1.057,0.961,1.282,1.184,1.128,1.148,0.969,0.979,1.164,0.728,0.788,1.322,0.915,0.764,1.115,1.181,1.055,0.674,1.165,0.925,0.883,1.264,1.312,0.989,1.087,0.958,0.967,1.12,1.078,1.149,1.381,1.01,0.839,0.626,0.932,1.041,0.702,1.03,1.069,1.071,0.892,0.667,0.976];
tree_cores(12,:)= [0.796,0.699,0.959,0.907,0.695,0.863,0.983,1.016,1.037,1.208,1.262,1.353,1.179,0.909,0.752,1.067,1.178,1.435,1.385,0.876,0.99,0.921,0.91,0.749,0.591,0.658,0.684,0.693,0.832,0.911,0.79,1.031,0.924,1.245,1.174,1.118,1.089,0.974,1.098,0.987,0.939,0.902,1.162,0.928,0.778,0.889,0.925,0.973,0.733,1.354,1.136,1.055,1.298,1.321,0.863,0.959,0.865,0.847,1.089,1.131,1.172,1.129,0.911,0.786,0.651,1.006,1.141,0.65,1.048,1.097,1.226,0.913,0.736,1.105];
tree_cores(13,:)= [0.834,0.74,0.847,0.877,0.724,0.894,0.853,1.012,1.069,1.131,1.346,1.313,1.113,0.875,0.776,0.868,0.922,1.214,1.183,1.046,0.85,0.931,0.938,1.017,0.821,0.941,0.876,0.873,0.923,1.012,0.905,1.086,0.957,1.098,1.137,1.176,1.134,0.948,0.981,0.949,0.723,0.675,1.033,0.818,0.729,0.946,1.104,1.074,0.774,1.108,0.904,0.901,1.187,1.186,0.866,1.07,1.014,0.881,1.178,1.198,1.159,1.318,1.055,0.922,0.65,0.984,1.357,0.813,0.926,0.878,1.163,0.822,0.719,0.89];
tree_cores(14,:)= [0.886,0.907,1.184,0.8,0.629,1.167,0.677,1.047,1.012,1.084,1.049,0.927,0.96,0.861,0.941,1.125,0.983,0.91,1.019,0.671,0.854,0.696,1.038,0.954,1.039,1.199,0.782,0.697,1.149,1.091,0.748,0.871,0.836,0.814,0.999,1.076,1.222,1.026,1.082,1.123,1.078,0.797,1.103,0.807,0.654,1.055,1.17,1.224,0.566,0.972,1.015,0.725,1.27,1.167,0.944,1.138,0.766,0.92,1.278,1.232,0.894,1.287,1.059,1.146,0.906,1.05,0.922,0.706,1.031,1.112,1.158,0.563,0.673,0.947];
tree_cores(15,:)= [0.914,0.652,1.033,1.028,0.823,1.272,1.01,1.011,0.947,0.842,0.654,0.727,1.216,1.324,0.951,1.242,0.987,1.141,1.196,0.756,0.979,0.839,0.533,0.864,0.669,0.776,0.64,0.733,1.452,1.417,0.802,1.147,1.145,1.315,1.18,1.066,0.937,0.775,1.026,1.259,1.203,0.886,1.267,0.618,0.515,1.043,1.206,1.379,0.35,0.87,1.385,0.861,1.287,1.421,0.52,0.805,0.668,0.612,1.475,1.123,1.034,1.294,0.952,0.976,1.017,1.047,1.286,0.655,1.159,1.2,1.154,0.817,0.376,0.645];
tree_cores(16,:)= [0.854,0.828,1.17,0.842,0.631,0.925,1.065,1.16,1.132,0.936,0.892,1.093,1.008,0.921,0.695,0.805,0.618,0.652,0.609,0.506,0.976,1.232,1.408,1.255,1.006,1.145,0.929,0.78,0.78,0.722,0.501,0.588,0.465,0.531,0.858,1.535,1.595,1.503,1.523,1.439,1.295,1.25,1.456,1.075,0.944,0.961,0.992,0.943,0.709,0.831,0.615,0.802,1.08,1.116,0.935,0.918,0.84,0.846,0.937,0.898,0.875,1.051,0.954,0.745,0.782,0.917,1.071,0.925,0.971,1.022,1.017,1.055,0.844,1.291];

tree = tree_cores(:,51:74);

% Tree ring 1  Dobbs_CAOV
% Tree ring 2  Hoot_CYOV
% Tree ring 3  Hoot_FRAM
% Tree ring 4  Hoot_LITU
% Tree ring 5  Hoot_QURU
% Tree ring 6  Latimer_ACSH
% Tree ring 7  Latimer_LITU
% Tree ring 8  Lily_ACSH
% Tree ring 9  Lily_CYOV
% Tree ring 10 Lily_LITU
% Tree ring 11 Lily_QUAL
% Tree ring 12 Lily_QUPR
% Tree ring 13 Lily_QUVE
% Tree ring 14 Morgan_ACSH
% Tree ring 15 Morgan_LITU
% Tree ring 16 Morgan_QUAL


%npp images
Npp_database = zeros(60,60,24);
Npp_database(:,:,1) =  imread('C:\Users\Administrator\Desktop\NPP test\test_data\NPPtest_1990.tif');
Npp_database(:,:,2) =  imread('C:\Users\Administrator\Desktop\NPP test\test_data\NPPtest_1991.tif');
Npp_database(:,:,3) =  imread('C:\Users\Administrator\Desktop\NPP test\test_data\NPPtest_1992.tif');
Npp_database(:,:,4) =  imread('C:\Users\Administrator\Desktop\NPP test\test_data\NPPtest_1993.tif');
Npp_database(:,:,5) =  imread('C:\Users\Administrator\Desktop\NPP test\test_data\NPPtest_1994.tif');
Npp_database(:,:,6) =  imread('C:\Users\Administrator\Desktop\NPP test\test_data\NPPtest_1995.tif');
Npp_database(:,:,7) =  imread('C:\Users\Administrator\Desktop\NPP test\test_data\NPPtest_1996.tif');
Npp_database(:,:,8) =  imread('C:\Users\Administrator\Desktop\NPP test\test_data\NPPtest_1997.tif');
Npp_database(:,:,9) =  imread('C:\Users\Administrator\Desktop\NPP test\test_data\NPPtest_1998.tif');
Npp_database(:,:,10)=  imread('C:\Users\Administrator\Desktop\NPP test\test_data\NPPtest_1999.tif');
Npp_database(:,:,11)=  imread('C:\Users\Administrator\Desktop\NPP test\test_data\NPPtest_2000.tif');
Npp_database(:,:,12)=  imread('C:\Users\Administrator\Desktop\NPP test\test_data\NPPtest_2001.tif');
Npp_database(:,:,13)=  imread('C:\Users\Administrator\Desktop\NPP test\test_data\NPPtest_2002.tif');
Npp_database(:,:,14)=  imread('C:\Users\Administrator\Desktop\NPP test\test_data\NPPtest_2003.tif');
Npp_database(:,:,15)=  imread('C:\Users\Administrator\Desktop\NPP test\test_data\NPPtest_2004.tif');
Npp_database(:,:,16)=  imread('C:\Users\Administrator\Desktop\NPP test\test_data\NPPtest_2005.tif');
Npp_database(:,:,17)=  imread('C:\Users\Administrator\Desktop\NPP test\test_data\NPPtest_2006.tif');
Npp_database(:,:,18)=  imread('C:\Users\Administrator\Desktop\NPP test\test_data\NPPtest_2007.tif');
Npp_database(:,:,19)=  imread('C:\Users\Administrator\Desktop\NPP test\test_data\NPPtest_2008.tif');
Npp_database(:,:,20)=  imread('C:\Users\Administrator\Desktop\NPP test\test_data\NPPtest_2009.tif');
Npp_database(:,:,21)=  imread('C:\Users\Administrator\Desktop\NPP test\test_data\NPPtest_2010.tif');
Npp_database(:,:,22)=  imread('C:\Users\Administrator\Desktop\NPP test\test_data\NPPtest_2011.tif');
Npp_database(:,:,23)=  imread('C:\Users\Administrator\Desktop\NPP test\test_data\NPPtest_2012.tif');
Npp_database(:,:,24)=  imread('C:\Users\Administrator\Desktop\NPP test\test_data\NPPtest_2013.tif');

%calculate R values

R_list = zeros(16,1);
best_cores = zeros(60,60,5);
x = 1;
for i = 1: 60;
    for j = 1:60;
        Npp = squeeze(Npp_database(i,j,1:24)).';
        
        if Npp_database(i,j,1)> 0;
        
            for k = 1: 16;
                temp_R = corrcoef (Npp, tree(k,:));
                R = temp_R (2,1);
                R_list(k,1) = R;
            end;

            descending = sort(R_list,'descend');

            best_1 = ismember(R_list,descending(1));
            while best_1(x) ~= 1;
                x = x+ 1;
            end;
            best_cores(i,j,1) = x;
            x = 1;

            best_2 = ismember(R_list,descending(2));
            while best_2(x) ~= 1;
                x = x+ 1;
            end;
            best_cores(i,j,2) = x;
            x = 1;

            best_3 = ismember(R_list,descending(3));
            while best_3(x) ~= 1;
                x = x+ 1;
            end;
            best_cores(i,j,3) = x;
            x = 1;

            best_4 = ismember(R_list,descending(4));
            while best_4(x) ~= 1;
                x = x+ 1;
            end;
            best_cores(i,j,4) = x;
            x = 1;



            best_5 = ismember(R_list,descending(5));
            while best_5(x) ~= 1;
                x = x+ 1;
            end;
            best_cores(i,j,5) = x;
            x = 1;


            R_list = [];
            
        end;
    
    end;
end;

Rsquared_Adjusted = zeros(60, 60);
p = zeros(60, 60);
simulated_NPP = zeros(60, 60, 73);

for i = 1: 60;
    for j = 1: 60;
        
        
        Npp = squeeze(Npp_database(i,j,1:24));
        
        % filter some points lower than 0
        
        
        for m = 1: 24;
            if Npp(m) < 0;
                Npp(m) = NaN;
            end;
        end;
                   
        if best_cores(i,j,1) * best_cores(i,j,2)* best_cores(i,j,3) * best_cores(i,j,4) * best_cores(i,j,5) ~= 0;
            
            xx1_total = (tree_cores(best_cores(i,j,1),:)).';
            xx2_total = (tree_cores(best_cores(i,j,2),:)).';
            xx3_total = (tree_cores(best_cores(i,j,3),:)).';
            xx4_total = (tree_cores(best_cores(i,j,4),:)).';
            xx5_total = (tree_cores(best_cores(i,j,5),:)).';

            X = [xx1_total xx2_total xx3_total xx4_total xx5_total];
            [coeff,PCAScores,PCAVar] = pca(X);
            Cumulative_variance = 100*cumsum(PCAVar(1:5))/sum(PCAVar(1:5));

            n = 1;
            while Cumulative_variance(n)<85;
                n = n+1;
            end;
            candidate_total = X*coeff(:,1:n-1);  

            % Generate the coefficients
            candidate_temp = candidate_total(51:74,:);


            %Simulated_model
            mdl = stepwiselm(candidate_temp,Npp,'PEnter',0.05);
            Rsquared_Adjusted(i,j)= mdl.Rsquared.Adjusted;
            p(i,j)= coefTest(mdl);



            candidate_f_temp = candidate_total(1:74,:);


            simulation(i,j,:) = predict(mdl, candidate_f_temp);
        end;
        
        if best_cores(i,j,1) * best_cores(i,j,2)* best_cores(i,j,3) * best_cores(i,j,4) * best_cores(i,j,5) == 0;
            simulation(i,j,:) = -1;
        end;
        
    end;
end;

imwrite2tif(simulation(:,:,1),[],'C:\Users\Administrator\Desktop\NPP test\result\simNpp1941_nocord.tif','double');
imwrite2tif(simulation(:,:,2),[],'C:\Users\Administrator\Desktop\NPP test\result\simNpp1942_nocord.tif','double');
imwrite2tif(simulation(:,:,3),[],'C:\Users\Administrator\Desktop\NPP test\result\simNpp1943_nocord.tif','double');
imwrite2tif(simulation(:,:,4),[],'C:\Users\Administrator\Desktop\NPP test\result\simNpp1944_nocord.tif','double');
imwrite2tif(simulation(:,:,5),[],'C:\Users\Administrator\Desktop\NPP test\result\simNpp1945_nocord.tif','double');
imwrite2tif(simulation(:,:,6),[],'C:\Users\Administrator\Desktop\NPP test\result\simNpp1946_nocord.tif','double');
imwrite2tif(simulation(:,:,7),[],'C:\Users\Administrator\Desktop\NPP test\result\simNpp1947_nocord.tif','double');
imwrite2tif(simulation(:,:,8),[],'C:\Users\Administrator\Desktop\NPP test\result\simNpp1948_nocord.tif','double');
imwrite2tif(simulation(:,:,9),[],'C:\Users\Administrator\Desktop\NPP test\result\simNpp1949_nocord.tif','double');
imwrite2tif(simulation(:,:,10),[],'C:\Users\Administrator\Desktop\NPP test\result\simNpp1950_nocord.tif','double');
imwrite2tif(simulation(:,:,11),[],'C:\Users\Administrator\Desktop\NPP test\result\simNpp1951_nocord.tif','double');
imwrite2tif(simulation(:,:,12),[],'C:\Users\Administrator\Desktop\NPP test\result\simNpp1952_nocord.tif','double');
imwrite2tif(simulation(:,:,13),[],'C:\Users\Administrator\Desktop\NPP test\result\simNpp1953_nocord.tif','double');
imwrite2tif(simulation(:,:,14),[],'C:\Users\Administrator\Desktop\NPP test\result\simNpp1954_nocord.tif','double');
imwrite2tif(simulation(:,:,15),[],'C:\Users\Administrator\Desktop\NPP test\result\simNpp1955_nocord.tif','double');
imwrite2tif(simulation(:,:,16),[],'C:\Users\Administrator\Desktop\NPP test\result\simNpp1956_nocord.tif','double');
imwrite2tif(simulation(:,:,17),[],'C:\Users\Administrator\Desktop\NPP test\result\simNpp1957_nocord.tif','double');
imwrite2tif(simulation(:,:,18),[],'C:\Users\Administrator\Desktop\NPP test\result\simNpp1958_nocord.tif','double');
imwrite2tif(simulation(:,:,19),[],'C:\Users\Administrator\Desktop\NPP test\result\simNpp1959_nocord.tif','double');
imwrite2tif(simulation(:,:,20),[],'C:\Users\Administrator\Desktop\NPP test\result\simNpp1960_nocord.tif','double');
imwrite2tif(simulation(:,:,21),[],'C:\Users\Administrator\Desktop\NPP test\result\simNpp1961_nocord.tif','double');
imwrite2tif(simulation(:,:,22),[],'C:\Users\Administrator\Desktop\NPP test\result\simNpp1962_nocord.tif','double');
imwrite2tif(simulation(:,:,23),[],'C:\Users\Administrator\Desktop\NPP test\result\simNpp1963_nocord.tif','double');
imwrite2tif(simulation(:,:,24),[],'C:\Users\Administrator\Desktop\NPP test\result\simNpp1964_nocord.tif','double');
imwrite2tif(simulation(:,:,25),[],'C:\Users\Administrator\Desktop\NPP test\result\simNpp1965_nocord.tif','double');
imwrite2tif(simulation(:,:,26),[],'C:\Users\Administrator\Desktop\NPP test\result\simNpp1966_nocord.tif','double');
imwrite2tif(simulation(:,:,27),[],'C:\Users\Administrator\Desktop\NPP test\result\simNpp1967_nocord.tif','double');
imwrite2tif(simulation(:,:,28),[],'C:\Users\Administrator\Desktop\NPP test\result\simNpp1968_nocord.tif','double');
imwrite2tif(simulation(:,:,29),[],'C:\Users\Administrator\Desktop\NPP test\result\simNpp1969_nocord.tif','double');
imwrite2tif(simulation(:,:,30),[],'C:\Users\Administrator\Desktop\NPP test\result\simNpp1970_nocord.tif','double');
imwrite2tif(simulation(:,:,31),[],'C:\Users\Administrator\Desktop\NPP test\result\simNpp1971_nocord.tif','double');
imwrite2tif(simulation(:,:,32),[],'C:\Users\Administrator\Desktop\NPP test\result\simNpp1972_nocord.tif','double');
imwrite2tif(simulation(:,:,33),[],'C:\Users\Administrator\Desktop\NPP test\result\simNpp1973_nocord.tif','double');
imwrite2tif(simulation(:,:,34),[],'C:\Users\Administrator\Desktop\NPP test\result\simNpp1974_nocord.tif','double');
imwrite2tif(simulation(:,:,35),[],'C:\Users\Administrator\Desktop\NPP test\result\simNpp1975_nocord.tif','double');
imwrite2tif(simulation(:,:,36),[],'C:\Users\Administrator\Desktop\NPP test\result\simNpp1976_nocord.tif','double');
imwrite2tif(simulation(:,:,37),[],'C:\Users\Administrator\Desktop\NPP test\result\simNpp1977_nocord.tif','double');
imwrite2tif(simulation(:,:,38),[],'C:\Users\Administrator\Desktop\NPP test\result\simNpp1978_nocord.tif','double');
imwrite2tif(simulation(:,:,39),[],'C:\Users\Administrator\Desktop\NPP test\result\simNpp1979_nocord.tif','double');
imwrite2tif(simulation(:,:,40),[],'C:\Users\Administrator\Desktop\NPP test\result\simNpp1980_nocord.tif','double');
imwrite2tif(simulation(:,:,41),[],'C:\Users\Administrator\Desktop\NPP test\result\simNpp1981_nocord.tif','double');
imwrite2tif(simulation(:,:,42),[],'C:\Users\Administrator\Desktop\NPP test\result\simNpp1982_nocord.tif','double');
imwrite2tif(simulation(:,:,43),[],'C:\Users\Administrator\Desktop\NPP test\result\simNpp1983_nocord.tif','double');
imwrite2tif(simulation(:,:,44),[],'C:\Users\Administrator\Desktop\NPP test\result\simNpp1984_nocord.tif','double');
imwrite2tif(simulation(:,:,45),[],'C:\Users\Administrator\Desktop\NPP test\result\simNpp1985_nocord.tif','double');
imwrite2tif(simulation(:,:,46),[],'C:\Users\Administrator\Desktop\NPP test\result\simNpp1986_nocord.tif','double');
imwrite2tif(simulation(:,:,47),[],'C:\Users\Administrator\Desktop\NPP test\result\simNpp1987_nocord.tif','double');
imwrite2tif(simulation(:,:,48),[],'C:\Users\Administrator\Desktop\NPP test\result\simNpp1988_nocord.tif','double');
imwrite2tif(simulation(:,:,49),[],'C:\Users\Administrator\Desktop\NPP test\result\simNpp1989_nocord.tif','double');
imwrite2tif(simulation(:,:,50),[],'C:\Users\Administrator\Desktop\NPP test\result\simNpp1990_nocord.tif','double');
imwrite2tif(simulation(:,:,51),[],'C:\Users\Administrator\Desktop\NPP test\result\simNpp1991_nocord.tif','double');
imwrite2tif(simulation(:,:,52),[],'C:\Users\Administrator\Desktop\NPP test\result\simNpp1992_nocord.tif','double');
imwrite2tif(simulation(:,:,53),[],'C:\Users\Administrator\Desktop\NPP test\result\simNpp1993_nocord.tif','double');
imwrite2tif(simulation(:,:,54),[],'C:\Users\Administrator\Desktop\NPP test\result\simNpp1994_nocord.tif','double');
imwrite2tif(simulation(:,:,55),[],'C:\Users\Administrator\Desktop\NPP test\result\simNpp1995_nocord.tif','double');
imwrite2tif(simulation(:,:,56),[],'C:\Users\Administrator\Desktop\NPP test\result\simNpp1996_nocord.tif','double');
imwrite2tif(simulation(:,:,57),[],'C:\Users\Administrator\Desktop\NPP test\result\simNpp1997_nocord.tif','double');
imwrite2tif(simulation(:,:,58),[],'C:\Users\Administrator\Desktop\NPP test\result\simNpp1998_nocord.tif','double');
imwrite2tif(simulation(:,:,59),[],'C:\Users\Administrator\Desktop\NPP test\result\simNpp1999_nocord.tif','double');
imwrite2tif(simulation(:,:,60),[],'C:\Users\Administrator\Desktop\NPP test\result\simNpp2000_nocord.tif','double');
imwrite2tif(simulation(:,:,61),[],'C:\Users\Administrator\Desktop\NPP test\result\simNpp2001_nocord.tif','double');
imwrite2tif(simulation(:,:,62),[],'C:\Users\Administrator\Desktop\NPP test\result\simNpp2002_nocord.tif','double');
imwrite2tif(simulation(:,:,63),[],'C:\Users\Administrator\Desktop\NPP test\result\simNpp2003_nocord.tif','double');
imwrite2tif(simulation(:,:,64),[],'C:\Users\Administrator\Desktop\NPP test\result\simNpp2004_nocord.tif','double');
imwrite2tif(simulation(:,:,65),[],'C:\Users\Administrator\Desktop\NPP test\result\simNpp2005_nocord.tif','double');
imwrite2tif(simulation(:,:,66),[],'C:\Users\Administrator\Desktop\NPP test\result\simNpp2006_nocord.tif','double');
imwrite2tif(simulation(:,:,67),[],'C:\Users\Administrator\Desktop\NPP test\result\simNpp2007_nocord.tif','double');
imwrite2tif(simulation(:,:,68),[],'C:\Users\Administrator\Desktop\NPP test\result\simNpp2008_nocord.tif','double');
imwrite2tif(simulation(:,:,69),[],'C:\Users\Administrator\Desktop\NPP test\result\simNpp2009_nocord.tif','double');
imwrite2tif(simulation(:,:,70),[],'C:\Users\Administrator\Desktop\NPP test\result\simNpp2010_nocord.tif','double');
imwrite2tif(simulation(:,:,71),[],'C:\Users\Administrator\Desktop\NPP test\result\simNpp2011_nocord.tif','double');
imwrite2tif(simulation(:,:,72),[],'C:\Users\Administrator\Desktop\NPP test\result\simNpp2012_nocord.tif','double');
imwrite2tif(simulation(:,:,73),[],'C:\Users\Administrator\Desktop\NPP test\result\simNpp2013_nocord.tif','double');
imwrite2tif(best_cores(:,:,1),[],'C:\Users\Administrator\Desktop\NPP test\result\best1_nocord.tif','double');
imwrite2tif(best_cores(:,:,2),[],'C:\Users\Administrator\Desktop\NPP test\result\best2_nocord.tif','double');
imwrite2tif(best_cores(:,:,3),[],'C:\Users\Administrator\Desktop\NPP test\result\best3_nocord.tif','double');
imwrite2tif(best_cores(:,:,4),[],'C:\Users\Administrator\Desktop\NPP test\result\best4_nocord.tif','double');
imwrite2tif(best_cores(:,:,5),[],'C:\Users\Administrator\Desktop\NPP test\result\best5_nocord.tif','double');



imwrite2tif(Rsquared_Adjusted,[],'C:\Users\Administrator\Desktop\NPP test\result\Rsquared_Adjusted_nocord.tif','double');
imwrite2tif(p,[],'C:\Users\Administrator\Desktop\NPP test\result\p_value_nocord.tif','double');

toc;
